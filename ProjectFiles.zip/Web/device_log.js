function Start(deviceName) {
    invokeAPI(deviceName);
    emptyTable();
}

var invokeAPI = function(deviceName) {

    // 디바이스 조회 URI
    // 5분간 LED상태 조회
    var time = prompt("조회 시간을 입력하시오 ex)from=2021-00-00 00:00:00&to=2021-00-00 00:00:00  :");
    var API_URI = 'https://b7iu16x5l0.execute-api.ap-northeast-2.amazonaws.com/prod_project/devices/' + deviceName + '/log?'+time; //from=2021-12-03 13:20:00&to=2021-12-03 13:25:00';               
    $.ajax(API_URI, {
        method: 'GET',
        contentType: "application/json",

        success: function (data, status, xhr) {

            var result = JSON.parse(data);
            setDataList(result.data);  // 성공시, 데이터 출력을 위한 함수 호출
            console.log(data);
        },
        error: function(xhr,status,e){
          //  document.getElementById("result").innerHTML="Error";
              alert("error");
        }
    });
};

// 테이블 데이터 삭제
var emptyTable = function() {
    $( '#mytable > tbody').empty();
    document.getElementById("result").innerHTML="조회 중입니다.";
}

// 데이터 출력을 위한 함수
var setDataList = function(data){

    $( '#mytable > tbody').empty();
    data.forEach(function(v){

        var tr1 = document.createElement("tr");
        var td1 = document.createElement("td");
        var td2 = document.createElement("td");
        td1.innerText = v.timestamp; 
        td2.innerText = v.LED;
        tr1.appendChild(td1);
        tr1.appendChild(td2);
        $("#mytable").append(tr1);
    })

    if(data.length>0){
            // 디바이스 목록 조회결과가 있는 경우 데이터가 없습니다 메시지 삭제
        document.getElementById("result").innerHTML="";
    } else if (data.length ==0) {
        document.getElementById("result").innerHTML="No Data";
    }
}