function DeviceStart() {
    invokeDeviceAPI();
    //emptyTable();
}

function invokeDeviceAPI() {

    // 디바이스 조회 URI
    var API_URI = 'https://b7iu16x5l0.execute-api.ap-northeast-2.amazonaws.com/prod_project/devices';
    
    $.ajax( API_URI, {
        method: 'GET',
        contentType: "application/json",
        
        success: function (data, status, xhr) {
           
            var device_result = JSON.parse(data);
            setDeviceList(device_result.things);
            console.log(data);
        },
        error: function(xhr,status,e){
            alert("error");
        }
    });
};
/*
var emptyTable = function() {
    $( '#devices > tbody').empty();
    document.getElementById("devices_result").innerHTML="조회 중입니다.";
}
*/
var setDeviceList = function(data){

    $( '#devices > tbody').empty();
    data.forEach(function(v){

        var tr1 = document.createElement("tr");
        var td1 = document.createElement("td");
        var td2 = document.createElement("td");
        //td1.innerText = v.thingName;
        td2.innerText = v.thingArn;

        var a = document.createElement('a');
        a.setAttribute('href', `javascript:Start('${v.thingName}')`);
        a.innerHTML = v.thingName;

        td1.append(a);

        tr1.appendChild(td1);
        tr1.appendChild(td2);
        $("#devices").append(tr1);
    })

    if(data.length>0){
            // 디바이스 목록 조회결과가 있는 경우 데이터가 없습니다 메시지 삭제
        document.getElementById("devices_result").innerHTML="";
    } else if (data.length ==0) {
        document.getElementById("devices_result").innerHTML="No Data";
    }
}